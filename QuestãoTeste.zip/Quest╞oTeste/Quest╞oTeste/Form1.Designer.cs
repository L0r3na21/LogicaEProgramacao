﻿namespace QuestãoTeste
{
    partial class FrmQuestao
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalculo = new System.Windows.Forms.Button();
            this.lblValor1 = new System.Windows.Forms.Label();
            this.lblValor2 = new System.Windows.Forms.Label();
            this.lblValor3 = new System.Windows.Forms.Label();
            this.txtValor1 = new System.Windows.Forms.TextBox();
            this.txtValor3 = new System.Windows.Forms.TextBox();
            this.txtValor2 = new System.Windows.Forms.TextBox();
            this.lblResultado1 = new System.Windows.Forms.Label();
            this.lblResultado2 = new System.Windows.Forms.Label();
            this.lblResultado3 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lnlNome = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalculo
            // 
            this.btnCalculo.Location = new System.Drawing.Point(246, 392);
            this.btnCalculo.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnCalculo.Name = "btnCalculo";
            this.btnCalculo.Size = new System.Drawing.Size(169, 72);
            this.btnCalculo.TabIndex = 0;
            this.btnCalculo.Text = "Calcular";
            this.btnCalculo.UseVisualStyleBackColor = true;
            this.btnCalculo.Click += new System.EventHandler(this.btnCalculo_Click);
            // 
            // lblValor1
            // 
            this.lblValor1.AutoSize = true;
            this.lblValor1.Location = new System.Drawing.Point(35, 145);
            this.lblValor1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblValor1.Name = "lblValor1";
            this.lblValor1.Size = new System.Drawing.Size(71, 30);
            this.lblValor1.TabIndex = 1;
            this.lblValor1.Text = "Valor1";
            // 
            // lblValor2
            // 
            this.lblValor2.AutoSize = true;
            this.lblValor2.Location = new System.Drawing.Point(246, 145);
            this.lblValor2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblValor2.Name = "lblValor2";
            this.lblValor2.Size = new System.Drawing.Size(71, 30);
            this.lblValor2.TabIndex = 2;
            this.lblValor2.Text = "Valor2";
            // 
            // lblValor3
            // 
            this.lblValor3.AutoSize = true;
            this.lblValor3.Location = new System.Drawing.Point(465, 145);
            this.lblValor3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblValor3.Name = "lblValor3";
            this.lblValor3.Size = new System.Drawing.Size(71, 30);
            this.lblValor3.TabIndex = 3;
            this.lblValor3.Text = "Valor3";
            // 
            // txtValor1
            // 
            this.txtValor1.Location = new System.Drawing.Point(35, 181);
            this.txtValor1.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtValor1.Name = "txtValor1";
            this.txtValor1.Size = new System.Drawing.Size(169, 35);
            this.txtValor1.TabIndex = 4;
            // 
            // txtValor3
            // 
            this.txtValor3.Location = new System.Drawing.Point(465, 181);
            this.txtValor3.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtValor3.Name = "txtValor3";
            this.txtValor3.Size = new System.Drawing.Size(169, 35);
            this.txtValor3.TabIndex = 5;
            // 
            // txtValor2
            // 
            this.txtValor2.Location = new System.Drawing.Point(246, 181);
            this.txtValor2.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtValor2.Name = "txtValor2";
            this.txtValor2.Size = new System.Drawing.Size(169, 35);
            this.txtValor2.TabIndex = 6;
            // 
            // lblResultado1
            // 
            this.lblResultado1.AutoSize = true;
            this.lblResultado1.Location = new System.Drawing.Point(12, 234);
            this.lblResultado1.Name = "lblResultado1";
            this.lblResultado1.Size = new System.Drawing.Size(121, 30);
            this.lblResultado1.TabIndex = 7;
            this.lblResultado1.Text = "Resultado1:";
            this.lblResultado1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblResultado2
            // 
            this.lblResultado2.AutoSize = true;
            this.lblResultado2.Location = new System.Drawing.Point(12, 283);
            this.lblResultado2.Name = "lblResultado2";
            this.lblResultado2.Size = new System.Drawing.Size(121, 30);
            this.lblResultado2.TabIndex = 8;
            this.lblResultado2.Text = "Resultado2:";
            // 
            // lblResultado3
            // 
            this.lblResultado3.AutoSize = true;
            this.lblResultado3.Location = new System.Drawing.Point(12, 329);
            this.lblResultado3.Name = "lblResultado3";
            this.lblResultado3.Size = new System.Drawing.Size(121, 30);
            this.lblResultado3.TabIndex = 9;
            this.lblResultado3.Text = "Resultado3:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(35, 79);
            this.txtNome.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(169, 35);
            this.txtNome.TabIndex = 10;
            // 
            // lnlNome
            // 
            this.lnlNome.AutoSize = true;
            this.lnlNome.Location = new System.Drawing.Point(35, 31);
            this.lnlNome.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lnlNome.Name = "lnlNome";
            this.lnlNome.Size = new System.Drawing.Size(75, 30);
            this.lnlNome.TabIndex = 11;
            this.lnlNome.Text = "Nome:";
            // 
            // FrmQuestao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ClientSize = new System.Drawing.Size(682, 496);
            this.Controls.Add(this.lnlNome);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblResultado3);
            this.Controls.Add(this.lblResultado2);
            this.Controls.Add(this.lblResultado1);
            this.Controls.Add(this.txtValor2);
            this.Controls.Add(this.txtValor3);
            this.Controls.Add(this.txtValor1);
            this.Controls.Add(this.lblValor3);
            this.Controls.Add(this.lblValor2);
            this.Controls.Add(this.lblValor1);
            this.Controls.Add(this.btnCalculo);
            this.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "FrmQuestao";
            this.Text = "Questão";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnCalculo;
        private Label lblValor1;
        private Label lblValor2;
        private Label lblValor3;
        private TextBox txtValor1;
        private TextBox txtValor3;
        private TextBox txtValor2;
        private Label lblResultado1;
        private Label lblResultado2;
        private Label lblResultado3;
        private TextBox txtNome;
        private Label lnlNome;
    }
}