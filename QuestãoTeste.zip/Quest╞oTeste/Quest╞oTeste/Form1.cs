namespace QuestãoTeste
{
    public partial class FrmQuestao : Form
    {
        public FrmQuestao()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculo_Click(object sender, EventArgs e)
        {
            string nome=(txtNome.Text);
           float Valor1 = float.Parse(txtValor1.Text);
            float valor2 = float.Parse(txtValor2.Text);
            float valor3 = float.Parse(txtValor3.Text);
            float soma1,soma2,soma3,resu1,resu2,resu3;
            soma1 = Valor1 * 10 / 100;
            soma2 = valor2 * 10 / 100;
            soma3 = valor3 * 10 /100;
            resu1 = Valor1 + soma1;
            resu2 = valor2 + soma2;
            resu3 = valor3 + soma3;

            lblResultado1.Text = nome + " " + "o valor a ser pago com o acrecimo e" + " " + resu1;
            lblResultado2.Text = nome + " " + "o valor a ser pago com o acrecimo e" + " " + resu2;
            lblResultado3.Text = nome + " " + "o valor a ser pago com o acrecimo e" + " " + resu3;
        }
    }
}