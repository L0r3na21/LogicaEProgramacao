﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoMensagem
{
    public partial class frmEnvioMensagem : Form
    {
        public frmEnvioMensagem()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão mostrar");
        }

        private void label4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no label Booleano");
                
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no label texto");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no label Interno");

        }

        private void frmEnvioMensagem_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Abriu o formulario :)");
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão limpar");
        }

        private void lblDecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no label decimal");
        }

        private void txtInterno_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterei um texto :)");
        }
    }
}
